from http.server import BaseHTTPRequestHandler, HTTPServer
import json
import os
import shutil
from copy import copy
from openpyxl import load_workbook
from openpyxl.cell.cell import MergedCell

# ============================================================
# CARGO EXCEL SERVER - FINAL RULE
# Android -> n8n -> ONE Python server -> ONE Excel file
#
# Folder:
#   C:\n8n-data\cargo
#
# Templates:
#   template_manifest.xlsx
#   STOWINGAN_PAG_TEMPLATE.xlsx
#
# Output:
#   Cargo_Manifest.xlsx
#
# Visible sheets:
#   1. Manifest
#   2. STOWINGAN PAG
#
# FINAL STOWING CHECKLIST RULE:
#   One row = one NO PAG.
#   ALL KG details/items with the same NO PAG are combined into ONE row.
#   Customer + Description come from the first non-empty item of that PAG.
#   TOTAL WEIGHT is the sum of the actual KG details supplied by Android.
#   STOWINGAN PAG keeps every actual KG detail; it does NOT replace
#   10,10 / 50,50,80 / 20 with subtotals.
#   PTI is NOT written to the checklist.
# ============================================================

BASE = r"C:\n8n-data\cargo"
MANIFEST_TEMPLATE = os.path.join(BASE, "template_manifest.xlsx")
STOWING_TEMPLATE = os.path.join(BASE, "STOWINGAN_PAG_TEMPLATE.xlsx")
OUTPUT = os.path.join(BASE, "Cargo_Manifest.xlsx")

HOST = "0.0.0.0"
PORT = 5000

# Zero-based PAG block starts from the supplied STOWINGAN PAG template.
PAG_ROWS = [0, 10, 22, 33, 43, 56, 66, 77]
PAG_BLOCK_HEIGHT = 10
PAG_SUMMARY_START = 88


def s(value):
    return "" if value is None else str(value).strip()


def to_float(value):
    if value is None:
        return 0.0
    if isinstance(value, (int, float)):
        return float(value)
    text = s(value).replace(" ", "")
    if not text:
        return 0.0
    try:
        return float(text.replace(",", "."))
    except (TypeError, ValueError):
        return 0.0


def fmt_num(value):
    value = float(value or 0)
    if value.is_integer():
        return int(value)
    return round(value, 3)


def parse_weights(value):
    """Android weight: '20, 20, 20' -> [20.0, 20.0, 20.0]."""
    if value is None:
        return []

    if isinstance(value, (list, tuple)):
        out = []
        for x in value:
            n = to_float(x)
            if n > 0:
                out.append(n)
        return out

    text = s(value)
    if not text:
        return []

    normalized = (
        text.replace(";", ",")
        .replace("\n", ",")
        .replace("|", ",")
    )

    out = []
    for part in normalized.split(","):
        part = part.strip()
        if not part:
            continue
        n = to_float(part)
        if n > 0:
            out.append(n)

    if out:
        return out

    for part in text.split():
        n = to_float(part)
        if n > 0:
            out.append(n)
    return out


def raw_item_weights(item):
    """Return ONLY the KG details supplied by Android/n8n.

    Important for the final Android rule:
      weight = "10, 10"     -> [10, 10]
      weight = "50, 50, 80" -> [50, 50, 80]
      weight = 20            -> [20]

    A subtotal is NEVER mixed into these details. It is only a fallback
    when no KG detail field exists at all.
    """
    # In the current n8n payload shown by the user, the Android KG details
    # arrive in `weight`. Keep it as the first and authoritative source.
    candidates = (
        item.get("weight"),
        item.get("weights"),
        item.get("kgList"),
        item.get("kg_list"),
        item.get("weightDetails"),
        item.get("weight_details"),
        item.get("rincianKg"),
        item.get("rincian_kg"),
        item.get("rincianKG"),
        item.get("kg"),
        item.get("kgs"),
    )
    for value in candidates:
        weights = parse_weights(value)
        if weights:
            return weights
    return []


def item_total_kg(item):
    weights = raw_item_weights(item)
    if weights:
        return sum(weights)
    return to_float(item.get("subTotal"))


def copy_cell(src, dst, copy_value=False):
    dst.value = src.value if copy_value else None

    if src.has_style:
        dst._style = copy(src._style)
    if src.number_format:
        dst.number_format = src.number_format
    if src.alignment:
        dst.alignment = copy(src.alignment)
    if src.protection:
        dst.protection = copy(src.protection)
    if src.hyperlink:
        dst._hyperlink = copy(src.hyperlink)
    if src.comment:
        dst.comment = copy(src.comment)


def copy_sheet_from_workbook(source_ws, target_wb, title):
    if title in target_wb.sheetnames:
        del target_wb[title]

    target = target_wb.create_sheet(title)
    target.sheet_format.defaultRowHeight = source_ws.sheet_format.defaultRowHeight
    target.sheet_format.defaultColWidth = source_ws.sheet_format.defaultColWidth

    for col_letter, dim in source_ws.column_dimensions.items():
        target.column_dimensions[col_letter].width = dim.width
        target.column_dimensions[col_letter].hidden = dim.hidden
        target.column_dimensions[col_letter].outlineLevel = dim.outlineLevel

    for idx, dim in source_ws.row_dimensions.items():
        target.row_dimensions[idx].height = dim.height
        target.row_dimensions[idx].hidden = dim.hidden
        target.row_dimensions[idx].outlineLevel = dim.outlineLevel

    for row in source_ws.iter_rows():
        for src in row:
            copy_cell(src, target.cell(src.row, src.column), copy_value=True)

    for merged in source_ws.merged_cells.ranges:
        target.merge_cells(str(merged))

    target.sheet_view.showGridLines = source_ws.sheet_view.showGridLines
    target.freeze_panes = source_ws.freeze_panes
    target.page_margins = copy(source_ws.page_margins)
    target.page_setup = copy(source_ws.page_setup)
    target.print_options = copy(source_ws.print_options)
    return target


def ensure_workbook():
    os.makedirs(BASE, exist_ok=True)

    if not os.path.exists(MANIFEST_TEMPLATE):
        raise FileNotFoundError("Template Manifest tidak ditemukan: " + MANIFEST_TEMPLATE)
    if not os.path.exists(STOWING_TEMPLATE):
        raise FileNotFoundError("Template STOWINGAN PAG tidak ditemukan: " + STOWING_TEMPLATE)

    if not os.path.exists(OUTPUT):
        shutil.copy2(MANIFEST_TEMPLATE, OUTPUT)

    wb = load_workbook(OUTPUT)
    try:
        if "Manifest" not in wb.sheetnames:
            source_wb = load_workbook(MANIFEST_TEMPLATE)
            try:
                copy_sheet_from_workbook(
                    source_wb[source_wb.sheetnames[0]], wb, "Manifest"
                )
            finally:
                source_wb.close()

        if "STOWINGAN PAG" not in wb.sheetnames:
            source_wb = load_workbook(STOWING_TEMPLATE)
            try:
                copy_sheet_from_workbook(
                    source_wb[source_wb.sheetnames[0]], wb, "STOWINGAN PAG"
                )
            finally:
                source_wb.close()

        order = ["Manifest", "STOWINGAN PAG"]
        remaining = [x for x in wb.sheetnames if x not in order]
        wb._sheets = [wb[x] for x in order + remaining]
        wb.save(OUTPUT)
        print("EXCEL SAVED:", OUTPUT)
    finally:
        wb.close()


def write_manifest(ws, items):
    """Android Manifest mapping: A No, B PTI, C Pcs/Cly, D blank,
    E Sub Total, F Description, G Customer."""
    first_row = 14
    base_capacity = 31
    needed = len(items)

    if needed > base_capacity:
        ws.insert_rows(45, amount=needed - base_capacity)

    clear_end = 13 + max(base_capacity, needed)
    for row in range(first_row, clear_end + 1):
        for col in range(1, 8):
            safe_clear(ws, row, col)

    for index, item in enumerate(items, start=1):
        row = first_row + index - 1
        safe_set(ws, row, 1, index)
        safe_set(ws, row, 2, s(item.get("pti")))
        safe_set(ws, row, 3, s(item.get("pcsQty")))
        safe_clear(ws, row, 4)
        safe_set(ws, row, 5, to_float(item.get("subTotal")) or fmt_num(item_total_kg(item)))
        safe_set(ws, row, 6, s(item.get("description")))
        safe_set(ws, row, 7, s(item.get("customer")))

    total_row = 45 + max(0, needed - base_capacity)
    ws.cell(total_row, 1).value = "TOTAL WEIGHT"
    if needed:
        last_row = first_row + needed - 1
        safe_set(ws, total_row, 3, f"=SUM(C{first_row}:C{last_row})")
        safe_set(ws, total_row, 4, f"=SUM(D{first_row}:D{last_row})")
        safe_set(ws, total_row, 5, f"=SUM(E{first_row}:E{last_row})")
    else:
        safe_set(ws, total_row, 3, 0)
        safe_set(ws, total_row, 4, 0)
        safe_set(ws, total_row, 5, 0)


def clear_pag_block(ws, start):
    for row in range(start + 3, start + PAG_BLOCK_HEIGHT + 1):
        for col in range(1, 47):
            safe_clear(ws, row, col)


def write_stowing(ws, items):
    global PAG_ROWS
    """Write STOWINGAN PAG exactly from the app's KG detail.

    FINAL RULE:
    - Same NO PAG uses ONE PAG block.
    - Customer is written once for the PAG.
    - Every KG detail from every Android record is written sequentially,
      unchanged, in the same KG column.
    - subTotal is used only as a fallback when an Android record contains
      no KG detail at all.
    """
    groups = {}
    order = []

    for item in items:
        pag = s(item.get("noPag"))
        if not pag:
            continue

        key = pag.upper()
        if key not in groups:
            groups[key] = []
            order.append(key)
        groups[key].append(item)

    if not order:
        raise ValueError("Data Stowing tidak memiliki noPag.")

    for key in order:
        pag_items = groups[key]
        pag = s(pag_items[0].get("noPag"))

        block = None

        # Reuse the template block already assigned to this PAG.
        for candidate in PAG_ROWS:
            if s(ws.cell(candidate + 1, 2).value).upper() == key:
                block = candidate
                break

        # Otherwise use the first empty PAG block.
        if block is None:
            for candidate in PAG_ROWS:
                if not s(ws.cell(candidate + 1, 2).value):
                    block = candidate
                    break

        if block is None:
            raise ValueError("Template STOWINGAN PAG penuh untuk PAG baru: " + pag)

        clear_pag_block(ws, block)
        safe_set(ws, block + 1, 2, pag)

        # Total PAG is the total of the actual KG details received from Android.
        total = 0.0
        for item in pag_items:
            weights = raw_item_weights(item)
            if weights:
                total += sum(weights)
            else:
                total += to_float(item.get("subTotal"))

        safe_set(ws, block + 1, 5, fmt_num(total))

        customer_row = block + 3
        kg_row = customer_row + 1

        # The template uses repeated vertical KG areas. For one PAG, keep
        # all records together instead of moving the next record to another
        # customer column.
        customer = ""
        for item in pag_items:
            if not customer:
                customer = s(item.get("customer"))

        safe_set(ws, customer_row, 1, customer)

        # ------------------------------------------------------------
        # DYNAMIC KG ROWS
        # ------------------------------------------------------------
        # Jangan menolak data hanya karena jumlah rincian KG lebih banyak
        # daripada ruang kosong bawaan template. Data Android adalah sumber
        # kebenaran. Jika ruang blok kurang, tambahkan baris tepat sebelum
        # blok PAG berikutnya sehingga blok berikutnya tetap aman.
        #
        # Contoh:
        #   10,10 + 50,50,80 + 20 = 6 rincian KG -> tulis semua 6.
        # Jika payload berikutnya menambah rincian lagi, baris template
        # diperpanjang otomatis, bukan HTTP 500.
        all_weights = []
        for item in pag_items:
            weights = raw_item_weights(item)
            if weights:
                all_weights.extend(weights)
            else:
                subtotal = to_float(item.get("subTotal"))
                if subtotal:
                    all_weights.append(subtotal)

        ordered_blocks = sorted(PAG_ROWS)
        try:
            pos = ordered_blocks.index(block)
        except ValueError:
            pos = -1

        if pos >= 0 and pos + 1 < len(ordered_blocks):
            next_block = ordered_blocks[pos + 1] + 1  # Excel row number
            available_rows = next_block - kg_row

            if len(all_weights) > available_rows:
                extra_rows = len(all_weights) - available_rows

                # Insert before the next PAG block. This keeps the next PAG
                # and all PAG setelahnya turun bersama isi template.
                ws.insert_rows(next_block, amount=extra_rows)

                # Update the in-memory block positions for later PAG groups.
                for i in range(pos + 1, len(PAG_ROWS)):
                    PAG_ROWS[i] += extra_rows

                # Recalculate the current boundary after insertion.
                next_block += extra_rows

        elif pos >= 0:
            # Last visible block: keep enough room before the summary area.
            summary_row = PAG_SUMMARY_START + 1
            available_rows = summary_row - kg_row

            if len(all_weights) > available_rows:
                extra_rows = len(all_weights) - available_rows
                ws.insert_rows(summary_row, amount=extra_rows)

        # Write every KG detail exactly as received from Android.
        for kg in all_weights:
            safe_set(ws, kg_row, 1, fmt_num(kg))
            kg_row += 1


def safe_clear(ws, row, col):
    """Clear only real Excel cells; skip non-top-left cells of merged ranges."""
    cell = ws.cell(row, col)
    if isinstance(cell, MergedCell):
        return
    cell.value = None


def safe_set(ws, row, col, value):
    """Write only to a real cell. A merged range must be written through its top-left cell."""
    cell = ws.cell(row, col)
    if isinstance(cell, MergedCell):
        # Find the merged range containing this coordinate.
        coord = cell.coordinate
        for rng in ws.merged_cells.ranges:
            if coord in rng:
                top_left = ws.cell(rng.min_row, rng.min_col)
                # Only redirect when the requested coordinate belongs to the merged
                # range and the top-left is the intended writable cell.
                top_left.value = value
                return
        return
    cell.value = value


def find_header_row_and_columns(ws):
    """Find the STOWING CHECKLIST header row and columns from existing labels."""
    for row in range(1, ws.max_row + 1):
        values = {}
        for col in range(1, ws.max_column + 1):
            text = s(ws.cell(row, col).value).upper()
            if text:
                values[text] = col

        no_col = values.get("NO") or values.get("NO.")
        pag_col = values.get("NO PAG") or values.get("NO. PAG") or values.get("PAG")
        desc_col = values.get("DESCRIPTION") or values.get("CARGO")
        cust_col = values.get("COSTUMERS") or values.get("CUSTOMERS") or values.get("CUSTOMER")

        if pag_col and desc_col and cust_col:
            weight_col = (
                values.get("NET")
                or values.get("WEIGHT (KG)")
                or values.get("WEIGHT(KG)")
                or values.get("WEIGHT")
            )
            if weight_col is None:
                for c in range(1, ws.max_column + 1):
                    if s(ws.cell(row + 1, c).value).upper() == "NET":
                        weight_col = c
                        break

            return row, no_col, pag_col, desc_col, weight_col, cust_col

    return None


def aggregate_checklist(items):
    """FINAL RULE: 1 checklist row per NO PAG.

    Semua item yang memiliki NO PAG sama digabung menjadi satu baris.
    KG dari seluruh item dalam PAG tersebut dijumlahkan.
    Customer dan Description mengikuti data pertama pada PAG tersebut,
    sesuai output aplikasi.
    """
    groups = {}
    order = []

    for item in items:
        pag = s(item.get("noPag"))
        if not pag:
            continue

        key = pag.upper()

        if key not in groups:
            groups[key] = {
                "noPag": pag,
                "customer": s(item.get("customer")),
                "description": s(item.get("description")),
                "weight": 0.0,
            }
            order.append(key)

        # Semua berat/item dengan NO PAG yang sama masuk ke total PAG yang sama.
        groups[key]["weight"] += item_total_kg(item)

        # Jika data pertama kosong, ambil nilai dari item berikutnya.
        if not groups[key]["customer"]:
            groups[key]["customer"] = s(item.get("customer"))
        if not groups[key]["description"]:
            groups[key]["description"] = s(item.get("description"))

    return [groups[key] for key in order]

def write_stowing_checklist(ws, items):
    """Write the final aggregated STOWING CHECKLIST."""
    found = find_header_row_and_columns(ws)
    if not found:
        raise ValueError(
            "Header STOWING CHECKLIST tidak ditemukan. Pastikan template Manifest "
            "mempunyai kolom No, NO PAG, DESCRIPTION, WEIGHT/NET dan COSTUMERS."
        )

    header_row, no_col, pag_col, desc_col, weight_col, cust_col = found
    rows = aggregate_checklist(items)

    if weight_col is None:
        raise ValueError("Kolom WEIGHT/NET pada STOWING CHECKLIST tidak ditemukan.")

    # Template STOWING CHECKLIST pada file asli memiliki area header
    # yang sebagian berupa merged cells. Jangan menulis ke row yang masih
    # berada di dalam merged header karena openpyxl akan mengarahkan nilai
    # ke top-left merged cell sehingga terlihat seperti "naik" ke header.
    #
    # Mulai dari bawah header, lalu lompat melewati merged range apa pun
    # yang masih menutupi baris target.
    first_data_row = max(header_row + 1, 14)

    changed = True
    while changed:
        changed = False
        for rng in ws.merged_cells.ranges:
            if rng.min_row <= first_data_row <= rng.max_row:
                first_data_row = rng.max_row + 1
                changed = True
                break

    end_row = ws.max_row
    for r in range(first_data_row, ws.max_row + 1):
        row_text = " ".join(
            s(ws.cell(r, c).value).upper()
            for c in range(1, ws.max_column + 1)
        )
        if "MANUAL LOAD" in row_text or "TOTAL WEIGHT" in row_text:
            end_row = r - 1
            break

    cols_to_clear = [c for c in [no_col, pag_col, desc_col, weight_col, cust_col] if c]
    for r in range(first_data_row, end_row + 1):
        for c in cols_to_clear:
            safe_clear(ws, r, c)

    for index, row_data in enumerate(rows):
        target = first_data_row + index
        if target > end_row:
            raise ValueError(
                "STOWING CHECKLIST tidak memiliki cukup baris untuk "
                f"{len(rows)} kombinasi PAG/customer/description."
            )

        if no_col:
            safe_set(ws, target, no_col, index + 1)
        safe_set(ws, target, pag_col, row_data["noPag"])
        safe_set(ws, target, desc_col, row_data["description"])
        safe_set(ws, target, weight_col, fmt_num(row_data["weight"]))
        safe_set(ws, target, cust_col, row_data["customer"])

    for r in range(first_data_row, ws.max_row + 1):
        row_text = " ".join(
            s(ws.cell(r, c).value).upper()
            for c in range(1, ws.max_column + 1)
        )
        if "TOTAL WEIGHT" in row_text:
            total = sum(x["weight"] for x in rows)
            safe_set(ws, r, weight_col, fmt_num(total))
            break

    print("STOWING CHECKLIST START ROW:", first_data_row)
    print("STOWING CHECKLIST GROUPING: 1 ROW PER NO PAG")
    print("STOWING CHECKLIST:")
    for row_data in rows:
        print(
            "  PAG =", row_data["noPag"],
            "| CUSTOMER =", row_data["customer"],
            "| DESCRIPTION =", row_data["description"],
            "| KG =", fmt_num(row_data["weight"])
        )

    return len(rows)


def write_combined(items):
    ensure_workbook()

    wb = load_workbook(OUTPUT)
    try:
        if "Manifest" not in wb.sheetnames:
            raise ValueError("Sheet Manifest tidak ada.")
        if "STOWINGAN PAG" not in wb.sheetnames:
            raise ValueError("Sheet STOWINGAN PAG tidak ada.")

        print("PAYLOAD STOWING FINAL:")
        for i, item in enumerate(items, start=1):
            print(
                f"  ITEM {i}: PAG={item.get('noPag')} "
                f"CUSTOMER={item.get('customer')} "
                f"DESCRIPTION={item.get('description')} "
                f"WEIGHT={item.get('weight')} "
                f"SUBTOTAL={item.get('subTotal')}"
            )

        write_manifest(wb["Manifest"], items)
        write_stowing_checklist(wb["Manifest"], items)
        write_stowing(wb["STOWINGAN PAG"], items)

        wb.calculation.fullCalcOnLoad = True
        wb.calculation.forceFullCalc = True
        wb.calculation.calcMode = "auto"
        wb.save(OUTPUT)
        print("EXCEL SAVED:", OUTPUT)
    finally:
        wb.close()


class Handler(BaseHTTPRequestHandler):
    def do_POST(self):
        allowed = (
            "/cargo/manifest",
            "/cargo/manifest/items",
            "/cargo/stowing",
        )

        if self.path not in allowed:
            self.send_json(404, {
                "success": False,
                "error": "Endpoint tidak ditemukan",
                "allowed": list(allowed),
            })
            return

        try:
            length = int(self.headers.get("Content-Length", "0"))
            raw = self.rfile.read(length)
            if not raw:
                raise ValueError("Request body kosong.")

            data = json.loads(raw.decode("utf-8"))
            items = data.get("items", [])

            if not isinstance(items, list) or not items:
                raise ValueError("items kosong atau bukan array.")

            normalized = []
            for item in items:
                normalized.append({
                    "pti": item.get("pti", ""),
                    "pcsQty": item.get("pcsQty", ""),
                    "weight": item.get("weight", ""),
                    "weights": item.get("weights", ""),
                    "kg": item.get("kg", ""),
                    "kgs": item.get("kgs", ""),
                    "kgList": item.get("kgList", ""),
                    "kg_list": item.get("kg_list", ""),
                    "weightDetails": item.get("weightDetails", ""),
                    "weight_details": item.get("weight_details", ""),
                    "rincianKg": item.get("rincianKg", ""),
                    "rincian_kg": item.get("rincian_kg", ""),
                    "rincianKG": item.get("rincianKG", ""),
                    "subTotal": item.get("subTotal", ""),
                    "description": item.get("description", ""),
                    "customer": item.get("customer", ""),
                    "noPag": item.get("noPag", ""),
                })

            checklist_rows = len(aggregate_checklist(normalized))
            write_combined(normalized)
            total_kg = sum(item_total_kg(item) for item in normalized)

            self.send_json(200, {
                "success": True,
                "message": (
                    "Data berhasil diproses ke 1 file Excel: "
                    "Manifest + STOWINGAN PAG + STOWING CHECKLIST."
                ),
                "file": OUTPUT,
                "itemsReceived": len(normalized),
                "checklistRows": checklist_rows,
                "totalKg": fmt_num(total_kg),
            })

        except PermissionError:
            self.send_json(423, {
                "success": False,
                "error": (
                    "Cargo_Manifest.xlsx sedang terbuka/dikunci. "
                    "Tutup Excel lalu kirim lagi."
                ),
            })

        except Exception as exc:
            print("")
            print("========== CARGO EXCEL ERROR ==========")
            print(str(exc))
            print("=======================================")
            self.send_json(500, {
                "success": False,
                "error": str(exc),
            })

    def send_json(self, status, payload):
        result = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(result)))
        self.end_headers()
        self.wfile.write(result)

    def log_message(self, fmt, *args):
        print(fmt % args)


print("==============================================")
print(" CARGO EXCEL SERVER - 1 SERVER FINAL")
print("==============================================")
print("Listening :", f"http://0.0.0.0:{PORT}")
print("Manifest  : /cargo/manifest/items")
print("Stowing   : /cargo/stowing")
print("Output    :", OUTPUT)
print("==============================================")

server = HTTPServer((HOST, PORT), Handler)
server.serve_forever()
