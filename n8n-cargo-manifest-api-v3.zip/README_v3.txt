# n8n Cargo Manifest API v3

Versi v3 adalah versi yang disiapkan sebagai versi final untuk pengujian laptop.

## Aturan penggabungan resmi

Data digabung hanya jika keempat field berikut sama:

- PTI
- NO PAG
- Customer
- Description

Jika sama:
- Pcs/Qty dijumlahkan
- Weight dijumlahkan
- Sub Total dijumlahkan

Jika PTI berbeda, data tetap menjadi baris berbeda.

Contoh:

KAL001 | 2 | 50 | 100 | CARGO | ULIN | PAG002
KAL001 | 3 | 40 | 120 | CARGO | ULIN | PAG002

menjadi:

KAL001 | 5 | 90 | 220 | CARGO | ULIN | PAG002

## Mapping Excel

PTI          -> B14+
Pcs/Qty      -> C14+
Pcs/Qty Wt   -> D14+
Sub Total    -> E14+
Description  -> F14+
Customer     -> G14+
NO PAG       -> T14+

Header berikut tetap manual dan tidak disentuh workflow:
A7 AWB No
C8 Date
G8 A/C Reg
C9 From
G9 Flight No
C10 To
G10 FLT FREQ

## Catatan

File ini belum diuji pada laptop pengguna karena laptop belum tersedia.
Jangan mengganti v2 di GitHub sebelum v3 diuji.
