import json
from pathlib import Path
from openpyxl import load_workbook

BASE = Path(r"C:\n8n\manifest")
TEMPLATE = BASE / "template_manifest.xlsx"
OUTPUT = BASE / "manifest_database.xlsx"

# n8n dapat mengirim payload melalui stdin jika script ini dijalankan
# sebagai proses. Payload yang valid harus memiliki objek {"items":[...]}.
raw = input()
payload = json.loads(raw)
items = payload.get("items", [])

if not items:
    raise ValueError("items kosong")

source = OUTPUT if OUTPUT.exists() else TEMPLATE
wb = load_workbook(source)
ws = wb["Manifest"]

START_ROW = 14
DATA_END = 44

# Bersihkan data lama pada area Manifest sebelum menulis hasil baru.
for row in range(START_ROW, DATA_END + 1):
    for col in [2, 3, 4, 5, 6, 7, 20]:
        ws.cell(row=row, column=col).value = None

# Tulis data yang sudah dikelompokkan oleh n8n.
for idx, item in enumerate(items, start=START_ROW):
    ws.cell(idx, 2).value = item["pti"]
    ws.cell(idx, 3).value = item["pcsQty"]
    ws.cell(idx, 4).value = item["weight"]
    ws.cell(idx, 5).value = item["subTotal"]
    ws.cell(idx, 6).value = item["description"]
    ws.cell(idx, 7).value = item["customer"]
    ws.cell(idx, 20).value = item["noPag"]

# Kolom T menjadi penyimpanan NO PAG dan dapat disembunyikan.
ws.column_dimensions["T"].hidden = True

wb.save(OUTPUT)
print(json.dumps({"ok": True, "file": str(OUTPUT), "rows": len(items)}))
