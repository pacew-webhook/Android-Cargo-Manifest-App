#!/usr/bin/env python3
import argparse, base64, json, os, shutil, tempfile, threading, copy
from pathlib import Path
from openpyxl import load_workbook
from openpyxl.formula.translate import Translator

START_ROW = 14
MANIFEST_DATA_COLS = {"pti": 2, "pcsQty": 3, "weight": 4, "subTotal": 5, "description": 6, "customer": 7}
NO_PAG_COL = 20  # T
STOWING_DATA_SHEET = "STOWING_DATA"
LOCK = threading.Lock()


def num(v):
    if v is None or str(v).strip() == "":
        return 0.0
    s = str(v).strip().replace(",", "")
    try:
        return float(s)
    except Exception:
        raise ValueError(f"Nilai angka tidak valid: {v}")


def clean(v):
    return "" if v is None else str(v).strip()


def next_manifest_row(ws):
    # Search only A:G; do not consider the hidden T column or formulas below the table.
    r = START_ROW
    while r <= ws.max_row:
        values = [ws.cell(r, c).value for c in range(1, 8)]
        if all(v in (None, "") for v in values):
            return r
        # Stop before the total row.
        text = " ".join(clean(v) for v in values)
        if "TOTAL" in text.upper():
            return r
        r += 1
    return r


def copy_row_style(ws, source_row, target_row):
    for c in range(1, max(ws.max_column, NO_PAG_COL) + 1):
        src = ws.cell(source_row, c)
        dst = ws.cell(target_row, c)
        if src.has_style:
            dst._style = copy.copy(src._style)
        if src.number_format:
            dst.number_format = src.number_format
        if src.alignment:
            dst.alignment = src.alignment.copy()
        if src.protection:
            dst.protection = src.protection.copy()


def insert_before_total(ws, row):
    # Current template total is row 45. If the next row is the total row,
    # insert a row and copy the previous data-row style.
    first_total = None
    for r in range(row, ws.max_row + 1):
        vals = [clean(ws.cell(r, c).value) for c in range(1, 8)]
        if any("TOTAL WEIGHT" in v.upper() for v in vals):
            first_total = r
            break
    if first_total is not None and row >= first_total:
        ws.insert_rows(first_total, 1)
        copy_row_style(ws, max(START_ROW, first_total - 1), first_total)
        # Keep T aligned with the inserted row.
        return first_total
    return row


def update_manifest_formulas(ws):
    # Find the visible Manifest total row.
    total_row = None
    for r in range(START_ROW, ws.max_row + 1):
        if clean(ws.cell(r, 1).value).upper() == "TOTAL WEIGHT":
            total_row = r
            break
    if total_row is None:
        return
    last_data = total_row - 1
    ws.cell(total_row, 3).value = f"=SUM(C{START_ROW}:C{last_data})"
    ws.cell(total_row, 4).value = None
    ws.cell(total_row, 5).value = f"=SUM(E{START_ROW}:E{last_data})"


def update_stowing_data(wb, items):
    if STOWING_DATA_SHEET in wb.sheetnames:
        ws = wb[STOWING_DATA_SHEET]
        # Rebuild from current Manifest rows so the hidden data remains authoritative.
        for row in ws.iter_rows():
            for cell in row:
                cell.value = None
    else:
        ws = wb.create_sheet(STOWING_DATA_SHEET)

    headers = ["No", "NO PAG", "PTI", "Customer", "Description", "Pcs/Cly", "Weight Detail", "Sub Total KG", "SYNC_ID"]
    for c, h in enumerate(headers, 1):
        ws.cell(1, c).value = h

    for i, item in enumerate(items, 1):
        vals = [
            i, clean(item.get("noPag")), clean(item.get("pti")), clean(item.get("customer")),
            clean(item.get("description")), clean(item.get("pcsQty")), clean(item.get("weight")),
            clean(item.get("subTotal")), clean(item.get("syncId"))
        ]
        for c, v in enumerate(vals, 1):
            ws.cell(i + 1, c).value = v
    ws.sheet_state = "veryHidden"


def all_manifest_items(ws):
    total_row = None
    for r in range(START_ROW, ws.max_row + 1):
        if clean(ws.cell(r, 1).value).upper() == "TOTAL WEIGHT":
            total_row = r
            break
    if total_row is None:
        total_row = ws.max_row + 1
    items = []
    for r in range(START_ROW, total_row):
        pti = clean(ws.cell(r, 2).value)
        if not pti and all(ws.cell(r, c).value in (None, "") for c in range(3, 8)):
            continue
        items.append({
            "pti": pti,
            "pcsQty": clean(ws.cell(r, 3).value),
            "weight": clean(ws.cell(r, 4).value),
            "subTotal": clean(ws.cell(r, 5).value),
            "description": clean(ws.cell(r, 6).value),
            "customer": clean(ws.cell(r, 7).value),
            "noPag": clean(ws.cell(r, NO_PAG_COL).value),
            "syncId": ""
        })
    return items


def group_items(items):
    """Group by NO PAG + Customer + Description.
    Aggregate numeric fields and keep unique PTIs in one cell separated by ' / '.
    """
    groups = {}
    order = []
    for item in items:
        key = (clean(item.get("noPag")).casefold(),
               clean(item.get("customer")).casefold(),
               clean(item.get("description")).casefold())
        if key not in groups:
            groups[key] = {
                "pti_list": [],
                "pcsQty": 0.0,
                "weight": 0.0,
                "subTotal": 0.0,
                "description": clean(item.get("description")),
                "customer": clean(item.get("customer")),
                "noPag": clean(item.get("noPag")),
                "sync_ids": []
            }
            order.append(key)
        g = groups[key]
        pti = clean(item.get("pti"))
        if pti and pti not in g["pti_list"]:
            g["pti_list"].append(pti)
        g["pcsQty"] += num(item.get("pcsQty"))
        g["weight"] += num(item.get("weight"))
        g["subTotal"] += num(item.get("subTotal"))
        sid = clean(item.get("syncId"))
        if sid:
            g["sync_ids"].append(sid)

    result = []
    for key in order:
        g = groups[key]
        result.append({
            "pti": " / ".join(g["pti_list"]),
            "pcsQty": str(int(g["pcsQty"]) if g["pcsQty"].is_integer() else g["pcsQty"]),
            "weight": str(int(g["weight"]) if g["weight"].is_integer() else g["weight"]),
            "subTotal": str(int(g["subTotal"]) if g["subTotal"].is_integer() else g["subTotal"]),
            "description": g["description"],
            "customer": g["customer"],
            "noPag": g["noPag"],
            "syncId": "|".join(g["sync_ids"])
        })
    return result

def merge_into_existing(existing, incoming):
    """Merge incoming groups into existing Excel rows using the official key."""
    merged = []
    index = {}
    for old in existing:
        item = {
            "pti": clean(old.get("pti")),
            "pcsQty": clean(old.get("pcsQty")),
            "weight": clean(old.get("weight")),
            "subTotal": clean(old.get("subTotal")),
            "description": clean(old.get("description")),
            "customer": clean(old.get("customer")),
            "noPag": clean(old.get("noPag")),
            "syncId": clean(old.get("syncId"))
        }
        key = (item["noPag"].casefold(), item["customer"].casefold(), item["description"].casefold())
        if key not in index:
            index[key] = len(merged)
            merged.append(item)
        else:
            g = merged[index[key]]
            ptis = [x.strip() for x in g["pti"].split(" / ") if x.strip()]
            for pti in [x.strip() for x in item["pti"].split(" / ") if x.strip()]:
                if pti not in ptis:
                    ptis.append(pti)
            g["pti"] = " / ".join(ptis)
            g["pcsQty"] = str(num(g["pcsQty"]) + num(item["pcsQty"]))
            g["weight"] = str(num(g["weight"]) + num(item["weight"]))
            g["subTotal"] = str(num(g["subTotal"]) + num(item["subTotal"]))

    for item in incoming:
        key = (clean(item["noPag"]).casefold(), clean(item["customer"]).casefold(), clean(item["description"]).casefold())
        if key in index:
            g = merged[index[key]]
            ptis = [x.strip() for x in g["pti"].split(" / ") if x.strip()]
            for pti in [x.strip() for x in clean(item["pti"]).split(" / ") if x.strip()]:
                if pti and pti not in ptis:
                    ptis.append(pti)
            g["pti"] = " / ".join(ptis)
            g["pcsQty"] = str(num(g["pcsQty"]) + num(item["pcsQty"]))
            g["weight"] = str(num(g["weight"]) + num(item["weight"]))
            g["subTotal"] = str(num(g["subTotal"]) + num(item["subTotal"]))
            if item.get("syncId"):
                old_ids = [x for x in g.get("syncId", "").split("|") if x]
                for sid in item["syncId"].split("|"):
                    if sid and sid not in old_ids:
                        old_ids.append(sid)
                g["syncId"] = "|".join(old_ids)
        else:
            index[key] = len(merged)
            merged.append(dict(item))
    return merged


def write_rows(ws, items):
    total_row = None
    for r in range(START_ROW, ws.max_row + 1):
        if clean(ws.cell(r, 1).value).upper() == "TOTAL WEIGHT":
            total_row = r
            break
    if total_row is None:
        total_row = START_ROW + len(items)

    # Ensure enough rows before the total row.
    required_total_row = START_ROW + len(items)
    while total_row < required_total_row:
        ws.insert_rows(total_row, 1)
        copy_row_style(ws, max(START_ROW, total_row - 1), total_row)
        total_row += 1

    # Write merged data rows.
    for idx, item in enumerate(items):
        r = START_ROW + idx
        if idx > 0:
            copy_row_style(ws, r - 1, r)
        ws.cell(r, 1).value = idx + 1
        ws.cell(r, 2).value = clean(item["pti"])
        ws.cell(r, 3).value = num(item["pcsQty"])
        ws.cell(r, 4).value = num(item["weight"]) if clean(item["weight"]) else None
        ws.cell(r, 5).value = num(item["subTotal"])
        ws.cell(r, 6).value = clean(item["description"])
        ws.cell(r, 7).value = clean(item["customer"])
        ws.cell(r, NO_PAG_COL).value = clean(item["noPag"])

    # Clear rows between last data row and total row.
    for r in range(START_ROW + len(items), total_row):
        for c in list(range(1, 8)) + [NO_PAG_COL]:
            ws.cell(r, c).value = None

    update_manifest_formulas(ws)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--payload", required=True, help="Base64 encoded JSON payload")
    ap.add_argument("--template", required=True)
    ap.add_argument("--output", required=True)
    args = ap.parse_args()

    payload = json.loads(base64.b64decode(args.payload).decode("utf-8"))
    items = payload.get("items")
    if not isinstance(items, list) or not items:
        raise ValueError("items harus berupa array dan tidak boleh kosong")

    validated = []
    for idx, raw in enumerate(items, 1):
        item = {
            "pti": clean(raw.get("pti")),
            "pcsQty": clean(raw.get("pcsQty")),
            "weight": clean(raw.get("weight")),
            "subTotal": clean(raw.get("subTotal")),
            "description": clean(raw.get("description")),
            "customer": clean(raw.get("customer")),
            "noPag": clean(raw.get("noPag")),
            "syncId": clean(raw.get("syncId"))
        }
        if not item["pti"]:
            raise ValueError(f"Item {idx}: PTI wajib diisi")
        if not item["pcsQty"]:
            raise ValueError(f"Item {idx}: Pcs/Qty wajib diisi")
        pcs = num(item["pcsQty"])
        weight = num(item["weight"])
        subtotal = num(item["subTotal"])
        if pcs <= 0:
            raise ValueError(f"Item {idx}: Pcs/Qty harus > 0")
        if weight < 0 or subtotal < 0:
            raise ValueError(f"Item {idx}: Weight/Sub Total tidak boleh negatif")
        if subtotal == 0 and weight > 0:
            subtotal = pcs * weight
            item["subTotal"] = str(int(subtotal) if subtotal.is_integer() else subtotal)
        validated.append(item)

    grouped = group_items(validated)

    template = Path(args.template)
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    if not output.exists():
        shutil.copy2(template, output)

    with LOCK:
        wb = load_workbook(output)
        ws = wb["Manifest"] if "Manifest" in wb.sheetnames else wb[wb.sheetnames[0]]

        existing = all_manifest_items(ws)
        merged = merge_into_existing(existing, grouped)
        write_rows(ws, merged)

        update_stowing_data(wb, merged)
        wb.calculation.fullCalcOnLoad = True
        wb.calculation.forceFullCalc = True
        wb.calculation.calcMode = "auto"
        wb.save(output)
        wb.close()

    result = {
        "success": True,
        "receivedItems": len(validated),
        "groupedItems": len(grouped),
        "finalExcelRows": len(merged),
        "output": str(output),
        "mapping": {
            "pti": "B14+",
            "pcsQty": "C14+",
            "weight": "D14+",
            "subTotal": "E14+",
            "description": "F14+",
            "customer": "G14+",
            "noPag": "T14+"
        },
        "groupingRule": "NO PAG + Customer + Description",
        "aggregation": {
            "pcsQty": "SUM",
            "weight": "SUM",
            "subTotal": "SUM",
            "pti": "UNIQUE PTI joined with ' / '"
        },
        "compatibility": "STOWING_DATA rebuilt for current Android importer"
    }
    print(json.dumps(result, ensure_ascii=False))

if __name__ == "__main__":
    main()
