N8N MANIFEST API - Cargo Manifest Android

Tujuan:
Android mengirim DATA BARANG ke n8n. n8n menulis ke template_manifest.xlsx yang sama dengan project Android.

Mapping yang digunakan:
PTI          -> B14+
Pcs/Qty      -> C14+
Pcs/Qty Wt   -> D14+
Sub Total    -> E14+
Description  -> F14+
Customer     -> G14+
NO PAG       -> T14+

Header A7, C8, G8, C9, G9, C10, G10 TIDAK disentuh oleh workflow.

Penting:
- T adalah kolom metadata NO PAG sesuai mapping yang diminta.
- Selain T, workflow juga membangun sheet STOWING_DATA (very hidden) agar tetap kompatibel dengan importer Android project saat ini. Ini bukan mengganti mapping T; ini lapisan kompatibilitas.
- File output default: manifest_database.xlsx
- Jika file output belum ada, script menyalin template_manifest.xlsx terlebih dahulu.
- Data baru ditambahkan ke baris kosong berikutnya sebelum TOTAL WEIGHT.
- Jika syncId dikirim ulang, item yang sama dilewati.

Instal Python package di laptop yang menjalankan n8n:
  pip install openpyxl

Lokasi default yang disarankan:
  C:\n8n\manifest\template_manifest.xlsx
  C:\n8n\manifest\manifest_database.xlsx
  C:\n8n\manifest\write_manifest.py

Ubah command Execute Command pada workflow sesuai OS/path laptop.

Contoh payload:
{
  "items": [
    {
      "pti": "KAL001",
      "pcsQty": 4,
      "weight": 50,
      "subTotal": 200,
      "description": "CARGO",
      "customer": "ULIN",
      "noPag": "PAG002 MYI",
      "syncId": "android-001"
    }
  ]
}


=== ATURAN PENGGABUNGAN DATA (VERSI 2) ===

Data akan otomatis digabung sebelum ditulis ke Excel apabila tiga nilai berikut sama:
1. NO PAG
2. Customer
3. Description

Jika ketiganya sama:
- Pcs/Qty dijumlahkan
- Pcs/Qty Wt (Weight) dijumlahkan
- Sub Total dijumlahkan
- PTI unik digabung dalam satu cell dengan pemisah " / "

Contoh:
KAL001 | 2 | 50 | 100 | CARGO | ULIN | PAG002 MYI
KAL002 | 3 | 40 | 120 | CARGO | ULIN | PAG002 MYI

Menjadi satu baris:
PTI = KAL001 / KAL002
Pcs/Qty = 5
Weight = 90
Sub Total = 220
Description = CARGO
Customer = ULIN
NO PAG = PAG002 MYI

Aturan yang sama juga diterapkan terhadap data yang sudah ada di manifest_database.xlsx, sehingga data baru dengan kombinasi NO PAG + Customer + Description yang sama akan ditambahkan ke baris yang sudah ada, bukan membuat baris baru.
