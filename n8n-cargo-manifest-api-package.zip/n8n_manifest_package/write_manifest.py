#!/usr/bin/env python3
import argparse, base64, json, os, shutil, tempfile, threading
from pathlib import Path
from openpyxl import load_workbook
from openpyxl.formula.translate import Translator

START_ROW = 14
MANIFEST_DATA_COLS = {"pti": 2, "pcsQty": 3, "weight": 4, "subTotal": 5, "description": 6, "customer": 7}
NO_PAG_COL = 20  # T
STOWING_DATA_SHEET = "STOWING_DATA"
LOCK = threading.Lock()


def num(v):
    if v is None or str(v).strip() == "":
        return 0.0
    s = str(v).strip().replace(",", "")
    try:
        return float(s)
    except Exception:
        raise ValueError(f"Nilai angka tidak valid: {v}")


def clean(v):
    return "" if v is None else str(v).strip()


def next_manifest_row(ws):
    # Search only A:G; do not consider the hidden T column or formulas below the table.
    r = START_ROW
    while r <= ws.max_row:
        values = [ws.cell(r, c).value for c in range(1, 8)]
        if all(v in (None, "") for v in values):
            return r
        # Stop before the total row.
        text = " ".join(clean(v) for v in values)
        if "TOTAL" in text.upper():
            return r
        r += 1
    return r


def copy_row_style(ws, source_row, target_row):
    for c in range(1, max(ws.max_column, NO_PAG_COL) + 1):
        src = ws.cell(source_row, c)
        dst = ws.cell(target_row, c)
        if src.has_style:
            dst._style = src._style.copy()
        if src.number_format:
            dst.number_format = src.number_format
        if src.alignment:
            dst.alignment = src.alignment.copy()
        if src.protection:
            dst.protection = src.protection.copy()


def insert_before_total(ws, row):
    # Current template total is row 45. If the next row is the total row,
    # insert a row and copy the previous data-row style.
    first_total = None
    for r in range(row, ws.max_row + 1):
        vals = [clean(ws.cell(r, c).value) for c in range(1, 8)]
        if any("TOTAL WEIGHT" in v.upper() for v in vals):
            first_total = r
            break
    if first_total is not None and row >= first_total:
        ws.insert_rows(first_total, 1)
        copy_row_style(ws, max(START_ROW, first_total - 1), first_total)
        # Keep T aligned with the inserted row.
        return first_total
    return row


def update_manifest_formulas(ws):
    # Find the visible Manifest total row.
    total_row = None
    for r in range(START_ROW, ws.max_row + 1):
        if clean(ws.cell(r, 1).value).upper() == "TOTAL WEIGHT":
            total_row = r
            break
    if total_row is None:
        return
    last_data = total_row - 1
    ws.cell(total_row, 3).value = f"=SUM(C{START_ROW}:C{last_data})"
    ws.cell(total_row, 4).value = None
    ws.cell(total_row, 5).value = f"=SUM(E{START_ROW}:E{last_data})"


def update_stowing_data(wb, items):
    if STOWING_DATA_SHEET in wb.sheetnames:
        ws = wb[STOWING_DATA_SHEET]
        # Rebuild from current Manifest rows so the hidden data remains authoritative.
        for row in ws.iter_rows():
            for cell in row:
                cell.value = None
    else:
        ws = wb.create_sheet(STOWING_DATA_SHEET)

    headers = ["No", "NO PAG", "PTI", "Customer", "Description", "Pcs/Cly", "Weight Detail", "Sub Total KG", "SYNC_ID"]
    for c, h in enumerate(headers, 1):
        ws.cell(1, c).value = h

    for i, item in enumerate(items, 1):
        vals = [
            i, clean(item.get("noPag")), clean(item.get("pti")), clean(item.get("customer")),
            clean(item.get("description")), clean(item.get("pcsQty")), clean(item.get("weight")),
            clean(item.get("subTotal")), clean(item.get("syncId"))
        ]
        for c, v in enumerate(vals, 1):
            ws.cell(i + 1, c).value = v
    ws.sheet_state = "veryHidden"


def all_manifest_items(ws):
    total_row = None
    for r in range(START_ROW, ws.max_row + 1):
        if clean(ws.cell(r, 1).value).upper() == "TOTAL WEIGHT":
            total_row = r
            break
    if total_row is None:
        total_row = ws.max_row + 1
    items = []
    for r in range(START_ROW, total_row):
        pti = clean(ws.cell(r, 2).value)
        if not pti and all(ws.cell(r, c).value in (None, "") for c in range(3, 8)):
            continue
        items.append({
            "pti": pti,
            "pcsQty": clean(ws.cell(r, 3).value),
            "weight": clean(ws.cell(r, 4).value),
            "subTotal": clean(ws.cell(r, 5).value),
            "description": clean(ws.cell(r, 6).value),
            "customer": clean(ws.cell(r, 7).value),
            "noPag": clean(ws.cell(r, NO_PAG_COL).value),
            "syncId": ""
        })
    return items


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--payload", required=True, help="Base64 encoded JSON payload")
    ap.add_argument("--template", required=True)
    ap.add_argument("--output", required=True)
    args = ap.parse_args()

    payload = json.loads(base64.b64decode(args.payload).decode("utf-8"))
    items = payload.get("items")
    if not isinstance(items, list) or not items:
        raise ValueError("items harus berupa array dan tidak boleh kosong")

    validated = []
    for idx, raw in enumerate(items, 1):
        item = {
            "pti": clean(raw.get("pti")),
            "pcsQty": clean(raw.get("pcsQty")),
            "weight": clean(raw.get("weight")),
            "subTotal": clean(raw.get("subTotal")),
            "description": clean(raw.get("description")),
            "customer": clean(raw.get("customer")),
            "noPag": clean(raw.get("noPag")),
            "syncId": clean(raw.get("syncId"))
        }
        if not item["pti"]:
            raise ValueError(f"Item {idx}: PTI wajib diisi")
        if not item["pcsQty"]:
            raise ValueError(f"Item {idx}: Pcs/Qty wajib diisi")
        pcs = num(item["pcsQty"])
        weight = num(item["weight"])
        subtotal = num(item["subTotal"])
        if pcs <= 0:
            raise ValueError(f"Item {idx}: Pcs/Qty harus > 0")
        if weight < 0 or subtotal < 0:
            raise ValueError(f"Item {idx}: Weight/Sub Total tidak boleh negatif")
        if subtotal == 0 and weight > 0:
            subtotal = pcs * weight
            item["subTotal"] = str(int(subtotal) if subtotal.is_integer() else subtotal)
        validated.append(item)

    template = Path(args.template)
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    if not output.exists():
        shutil.copy2(template, output)

    with LOCK:
        wb = load_workbook(output)
        ws = wb["Manifest"] if "Manifest" in wb.sheetnames else wb[wb.sheetnames[0]]

        existing = all_manifest_items(ws)
        existing_sync = {x["syncId"] for x in existing if x.get("syncId")}
        added = []

        for item in validated:
            if item["syncId"] and item["syncId"] in existing_sync:
                continue
            row = next_manifest_row(ws)
            if row >= ws.max_row or clean(ws.cell(row, 1).value).upper() == "TOTAL WEIGHT":
                row = insert_before_total(ws, row)
            if row > START_ROW:
                copy_row_style(ws, row - 1, row)
            ws.cell(row, 1).value = row - START_ROW + 1
            ws.cell(row, 2).value = item["pti"]
            ws.cell(row, 3).value = num(item["pcsQty"])
            ws.cell(row, 4).value = num(item["weight"]) if item["weight"] else None
            ws.cell(row, 5).value = num(item["subTotal"])
            ws.cell(row, 6).value = item["description"]
            ws.cell(row, 7).value = item["customer"]
            ws.cell(row, NO_PAG_COL).value = item["noPag"]
            added.append(item)
            existing.append(item)
            if item["syncId"]:
                existing_sync.add(item["syncId"])

        # Renumber visible rows after append.
        total_row = None
        for r in range(START_ROW, ws.max_row + 1):
            if clean(ws.cell(r, 1).value).upper() == "TOTAL WEIGHT":
                total_row = r
                break
        if total_row:
            n = 1
            for r in range(START_ROW, total_row):
                if any(ws.cell(r, c).value not in (None, "") for c in range(2, 8)):
                    ws.cell(r, 1).value = n
                    n += 1
            update_manifest_formulas(ws)

        # Keep NO PAG synchronized in the hidden sheet used by the Android importer.
        current = all_manifest_items(ws)
        update_stowing_data(wb, current)
        wb.calculation.fullCalcOnLoad = True
        wb.calculation.forceFullCalc = True
        wb.calculation.calcMode = "auto"
        wb.save(output)
        wb.close()

    result = {
        "success": True,
        "added": len(added),
        "skippedDuplicate": len(validated) - len(added),
        "output": str(output),
        "mapping": {
            "pti": "B14+",
            "pcsQty": "C14+",
            "weight": "D14+",
            "subTotal": "E14+",
            "description": "F14+",
            "customer": "G14+",
            "noPag": "T14+"
        },
        "compatibility": "STOWING_DATA rebuilt for current Android importer"
    }
    print(json.dumps(result, ensure_ascii=False))

if __name__ == "__main__":
    main()
